<?php
include_once("bdd.php");
if(isset($_POST['envoyer']))
{
    if(!empty($_POST['prenom']) && !empty($_POST['email']) && !empty($_POST['age']) && !empty($_POST['sex']) && !empty($_POST['pays']) )
    {
        $prenom=filter_input(INPUT_POST,"prenom",FILTER_SANITIZE_FULL_SPECIAL_CHARS);
        $email=filter_input(INPUT_POST,"email",FILTER_SANITIZE_EMAIL);
        $age=filter_input(INPUT_POST,"age",FILTER_SANITIZE_NUMBER_INT);
        $sex=filter_input(INPUT_POST,"sex",FILTER_SANITIZE_SPECIAL_CHARS);
        $pays=filter_input(INPUT_POST,"pays",FILTER_SANITIZE_SPECIAL_CHARS);

        if(!empty($prenom) && !empty($email) && !empty($age) && !empty($sex) && !empty($pays))
        {
            $insertion = $bdd->PREPARE("INSERT INTO admin values(?,?,?,?,?,?)");
            $insertion->EXECUTE(array("",$prenom,$email,$age,$sex,$pays));
            
        }

    }
}


?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="index.css">
    <title>Rgister</title>
</head>

<body>
    <form action="" method="post">
        <div class="formulaire">
            <div class="inline">

                <label for="prenom" class="label">
                    Prénom
                </label>
                <input type="text" name="prenom" id="prenom" placeholder="Pierre" required="">
            </div>
            <div class="inline">

                <label for="email" class="label">
                    Email
                </label>
                <input type="email" name="email" id="email" placeholder="pierre@gmail.com" required="">
            </div>
            <div class="inline">

                <label for="age" class="label">
                    Age
                </label>
                <input type="text" name="age" id="age" placeholder="Pierre" required="">
            </div>

            <div class=" radio">

                <div class="radio">
                    <div class="radio_line">
                        <input type="radio" name="sex" id="femme" value="Femme">
                        <label for="femme">Femme</label>
                    </div>
                    <div class="radio_line">
                        <input type="radio" name="sex" id="Homme" value="Homme">
                        <label for="Homme">Homme</label>
                    </div>
                    <div class="radio_line">
                        <input type="radio" name="sex" id="autre" value="Autre">
                        <label for="autre">Autre</label>
                    </div>
                </div>



            </div>
            <div class="inline">


                <label for="pays" class="label">
                    Pays de résidence
                </label>
                <select name="pays" id="pays">
                    <option value="France">France</option>
                    <option value="Bénin">Bénin</option>
                    <option value="Togo">Togo</option>

                </select>

            </div>

            <div class="inline">
                <input type="submit" value="Envoyer" name="envoyer">
            </div>


        </div>
    </form>

</body>

</html>