<?php
include_once("bdd.php");
$select=$bdd->PREPARE(" SELECT prenom,email,age,pays FROM admin");
$select->EXECUTE();
$listes=$select->fetchall();

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>liste des admins</title>
</head>

<body>
    <table>
        <th>
            <tr>
                <td>Prénom</td>
                <td>Email</td>
                <td>Age</td>
                <td>Pays</td>
            </tr>
            <?php
            foreach($listes as $liste)
            {
                ?>
            <tr>
                <td><?=$liste['prenom'];?></td>
                <td><?=$liste['email'];?></td>
                <td><?=$liste['age'];?></td>
                <td><?=$liste['pays'];?></td>
            </tr>
            <?php
            }
            ?>
        </th>
    </table>

</body>

</html>